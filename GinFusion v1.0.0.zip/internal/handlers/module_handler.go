package handlers

import (
	"database/sql"
	"net/http"
	"regexp"
	"strconv"

	"github.com/gin-gonic/gin"
	_ "github.com/mattn/go-sqlite3"
)

// regexCPF is used to clean CPF input.
var regexCPF = regexp.MustCompile(`\D`)

// openDB opens a SQLite database connection.
func openDB(path string) (*sql.DB, error) {
    db, err := sql.Open("sqlite3", path)
    if err != nil {
        return nil, err
    }
    return db, nil
}

// scanRows scans sql.Rows and returns a slice of maps where each map represents a row.
func scanRows(rows *sql.Rows) ([]map[string]interface{}, error) {
	cols, err := rows.Columns()
	if err != nil {
		return nil, err
	}
	results := []map[string]interface{}{}
	for rows.Next() {
		columns := make([]interface{}, len(cols))
		columnPointers := make([]interface{}, len(cols))
		for i := range columns {
			columnPointers[i] = &columns[i]
		}
		if err := rows.Scan(columnPointers...); err != nil {
			return nil, err
		}
		rowMap := make(map[string]interface{})
		for i, colName := range cols {
			val := columnPointers[i].(*interface{})
			if b, ok := (*val).([]byte); ok {
				rowMap[colName] = string(b)
			} else {
				rowMap[colName] = *val
			}
		}
		results = append(results, rowMap)
	}
	return results, nil
}

// DBQuery handles GET /consulta/cpf/:cpf
// Queries the first SQLite database: 230M-ASSECC-TELEFONIA.db
func DBQuery(c *gin.Context) {
	cpf := c.Param("cpf")
	db, err := openDB("/server/tele_srv/230M-ASSECC-TELEFONIA.db")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to connect to DB1", "details": err.Error()})
		return
	}
	defer db.Close()

	query := "SELECT * FROM PF WHERE CPF = ?"
	rows, err := db.Query(query, cpf)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database query failed", "details": err.Error()})
		return
	}
	defer rows.Close()

	results, err := scanRows(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to scan results", "details": err.Error()})
		return
	}
	if len(results) > 0 {
		c.JSON(http.StatusOK, results)
	} else {
		c.JSON(http.StatusNotFound, gin.H{"message": "Nenhum resultado encontrado"})
	}
}

// ConsultaBancoCPF handles GET /consulta/banco/cpf/:cpf
// Queries the second SQLite database: SRS_TB_IRPF.db
func ConsultaBancoCPF(c *gin.Context) {
	cpf := c.Param("cpf")
	db, err := openDB("/server/tele_srv/SRS_TB_IRPF.db")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to connect to DB2", "details": err.Error()})
		return
	}
	defer db.Close()

	query := "SELECT * FROM SRS_TB_IRPF WHERE DocNumber = ?"
	rows, err := db.Query(query, cpf)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database query failed", "details": err.Error()})
		return
	}
	defer rows.Close()

	results, err := scanRows(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to scan results", "details": err.Error()})
		return
	}
	if len(results) > 0 {
		c.JSON(http.StatusOK, results)
	} else {
		c.JSON(http.StatusNotFound, gin.H{"message": "Nenhum resultado encontrado"})
	}
}

// ConsultaWANumero handles GET /consulta/wa/numero/:numero
// Queries the third SQLite database: DB_ZAP.db
func ConsultaWANumero(c *gin.Context) {
	numero := c.Param("numero")
	db, err := openDB("/server/tele_srv/DB_ZAP.db")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to connect to DB3", "details": err.Error()})
		return
	}
	defer db.Close()

	query := "SELECT * FROM dados WHERE numero = ?"
	rows, err := db.Query(query, numero)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database query failed", "details": err.Error()})
		return
	}
	defer rows.Close()

	results, err := scanRows(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to scan results", "details": err.Error()})
		return
	}
	if len(results) > 0 {
		c.JSON(http.StatusOK, results)
	} else {
		c.JSON(http.StatusNotFound, gin.H{"message": "Nenhum resultado encontrado"})
	}
}

// ConsultaDataCPF handles GET /consulta/data/cpf/:cpf
// Queries multiple SQLite databases for detailed data.
func ConsultaDataCPF(c *gin.Context) {
	cpf := c.Param("cpf")
	cpf = regexCPF.ReplaceAllString(cpf, "") // Clean CPF input

	// Connect to contatosCompleto.db
	dbContatos, err := openDB("/server/contatosCompleto.db")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to connect to contatosCompleto.db", "details": err.Error()})
		return
	}
	defer dbContatos.Close()

	queryContatos := "SELECT * FROM Contatos WHERE CPF = ? LIMIT 1"
	rows, err := dbContatos.Query(queryContatos, cpf)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to query Contatos", "details": err.Error()})
		return
	}
	basicos, err := scanRows(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to scan Contatos results", "details": err.Error()})
		return
	}
	if len(basicos) == 0 {
		c.JSON(http.StatusNotFound, gin.H{"message": "CPF não encontrado"})
		return
	}

	// Extract CONTATOS_ID.
	var cttID uint
	switch v := basicos[0]["CONTATOS_ID"].(type) {
	case int64:
		cttID = uint(v)
	case float64:
		cttID = uint(v)
	case string:
		parsed, err := strconv.ParseUint(v, 10, 32)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to parse CONTATOS_ID", "details": err.Error()})
			return
		}
		cttID = uint(parsed)
	default:
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Unsupported type for CONTATOS_ID"})
		return
	}

	// Query Enderecos.db
	dbEnderecos, err := openDB("/server/Enderecos.db")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to connect to Enderecos.db", "details": err.Error()})
		return
	}
	defer dbEnderecos.Close()

	queryEnderecos := "SELECT * FROM enderecos WHERE Contatos_id = ? LIMIT 10"
	rows, err = dbEnderecos.Query(queryEnderecos, cttID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to query Enderecos", "details": err.Error()})
		return
	}
	enderecos, err := scanRows(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to scan Enderecos", "details": err.Error()})
		return
	}

	// Query TELEFONES.db
	dbTelefones, err := openDB("/server/TELEFONES.db")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to connect to TELEFONES.db", "details": err.Error()})
		return
	}
	defer dbTelefones.Close()

	queryTelefones := "SELECT * FROM TELEFONES WHERE id = ? LIMIT 10"
	rows, err = dbTelefones.Query(queryTelefones, cttID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to query Telefones", "details": err.Error()})
		return
	}
	telefones, err := scanRows(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to scan Telefones", "details": err.Error()})
		return
	}

	// Query EMAIL_NEW.db
	dbEmails, err := openDB("/server/EMAIL_NEW.db")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to connect to EMAIL_NEW.db", "details": err.Error()})
		return
	}
	defer dbEmails.Close()

	queryEmails := "SELECT * FROM EMAIL_NEW WHERE CONTATOS_ID = ? LIMIT 10"
	rows, err = dbEmails.Query(queryEmails, cttID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to query Emails", "details": err.Error()})
		return
	}
	emails, err := scanRows(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to scan Emails", "details": err.Error()})
		return
	}

	response := map[string]interface{}{
		"Basicos":   basicos,
		"Enderecos": enderecos,
		"Telefones": telefones,
		"Emails":    emails,
	}
	c.JSON(http.StatusOK, response)
}
