package routes

import (
	"time"

	"github.com/gin-gonic/gin"
	"github.com/0xPixelNinja/GinFusion/internal/handlers"
	"github.com/0xPixelNinja/GinFusion/internal/middleware"
	"github.com/0xPixelNinja/GinFusion/internal/repository"
)

// RegisterModuleRoutes sets up routes for module endpoints.
// All endpoints require an API key (passed as a query parameter).
func RegisterModuleRoutes(r *gin.Engine) {
	// Group all module endpoints under the "/consulta" path.
	modules := r.Group("/consulta")
	
	// Apply middleware:
	// 1. RequireAPIKey ensures an API key is provided as a query parameter.
	// 2. RateLimitMiddlewareWithAPIKey applies dynamic rate limiting.
	// 3. ConcurrencyLimitMiddlewareWithAPIKey limits concurrent requests.
	modules.Use(middleware.RequireAPIKey())
	modules.Use(middleware.RateLimitMiddlewareWithAPIKey(repository.GetRedisClient(), 20, time.Minute))
	modules.Use(middleware.ConcurrencyLimitMiddlewareWithAPIKey(10))
	modules.Use(middleware.RecordStatsMiddleware())

	// Register endpoints:
	// GET /consulta/cpf/:cpf - Queries the first SQLite DB (230M-ASSECC-TELEFONIA.db)
	modules.GET("/cpf/:cpf", handlers.DBQuery)

	// GET /consulta/banco/cpf/:cpf - Queries the second SQLite DB (SRS_TB_IRPF.db)
	modules.GET("/banco/cpf/:cpf", handlers.ConsultaBancoCPF)

	// GET /consulta/wa/numero/:numero - Queries the third SQLite DB (DB_ZAP.db)
	modules.GET("/wa/numero/:numero", handlers.ConsultaWANumero)

	// GET /consulta/data/cpf/:cpf - Performs a detailed query across multiple SQLite databases
	modules.GET("/data/cpf/:cpf", handlers.ConsultaDataCPF)
}
